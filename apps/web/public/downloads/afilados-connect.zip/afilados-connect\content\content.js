// Content Script para extração rápida e botão flutuante

(function () {
  // Helper para extrair valor numérico de um único container de preço (.andes-money-amount)
  function parseAndesMoney(el) {
    if (!el) return null;
    const fracEl = el.querySelector('.andes-money-amount__fraction');
    if (!fracEl) return null;
    const frac = fracEl.textContent.replace(/\./g, '').trim();
    const centsEl = el.querySelector('.andes-money-amount__cents');
    const cents = centsEl ? centsEl.textContent.trim() : null;
    const val = parseFloat(frac + (cents ? `.${cents}` : ''));
    return isNaN(val) ? null : val;
  }

  // Helper para verificar se uma palavra é stopword/termo genérico de cupom
  function isCouponStopword(word) {
    if (!word || typeof word !== 'string') return true;
    const upper = word.trim().toUpperCase();
    if (upper.length < 3 || upper.length > 25) return true;
    if (/^\d+$/.test(upper)) return true;
    const stopwords = window.AFILADOS_COUPON_STOPWORDS;
    if (stopwords && stopwords.has(upper)) return true;
    return false;
  }

  // Extrai código de cupom com escopo restrito a containers promocionais da loja
  function extractCouponFromScope(scope, storeKey) {
    if (!scope) return null;
    const stores = window.AFILADOS_COUPON_STORES || {};
    const store = stores[storeKey];
    const selectors = (store && store.productCouponSelectors) || [
      '[class*="coupon"]',
      '[class*="cupom"]',
      '[class*="voucher"]',
      '[class*="promo"]',
    ];

    // 1. Tenta seletores específicos de cupom/promoção
    for (const sel of selectors) {
      const els = scope.querySelectorAll(sel);
      for (const el of els) {
        const text = el.textContent || '';
        const keywordMatch = text.match(
          /(?:cupom|c[oó]digo|voucher|promo(?:code)?|claim\s*code)[\s:]+([A-Za-z0-9_\-]{3,20})/i,
        );
        if (keywordMatch && !isCouponStopword(keywordMatch[1])) {
          return keywordMatch[1].toUpperCase();
        }
        const trimmed = text.trim();
        if (/^[A-Za-z0-9_\-]{4,15}$/.test(trimmed) && !isCouponStopword(trimmed)) {
          return trimmed.toUpperCase();
        }
      }
    }

    // 2. Fallback em containers de preço restritos (evita pegar o body inteiro)
    const priceContainer = scope.querySelector(
      '.ui-pdp-price, #corePrice_feature_div, [data-testid*="price"], [class*="price-default"], .product-price',
    );
    if (priceContainer) {
      const match = priceContainer.textContent.match(
        /(?:cupom|c[oó]digo|voucher)[\s:]+([A-Za-z0-9_\-]{3,20})/i,
      );
      if (match && !isCouponStopword(match[1])) {
        return match[1].toUpperCase();
      }
    }

    return null;
  }

  // Extrai metadados de produto para parceiros AWIN e lojas de e-commerce universais
  function extractProductFromAwinPartner() {
    let title = '';
    let price = null;
    let originalPrice = null;
    let images = [];
    let couponCode = null;

    function toAbsUrl(src) {
      if (!src || typeof src !== 'string') return null;
      src = src.trim();
      if (!src || src.startsWith('data:image/svg') || src.startsWith('data:image/gif')) return null;
      if (src.startsWith('//')) return `https:${src}`;
      if (src.startsWith('http://') || src.startsWith('https://')) return src;
      try {
        return new URL(src, window.location.href).href;
      } catch {
        return null;
      }
    }

    function addImage(url) {
      const abs = toAbsUrl(url);
      if (abs && abs.startsWith('http') && !images.includes(abs)) {
        images.push(abs);
      }
    }

    // 1. Extração via Schema.org JSON-LD (universal para e-commerces: Drogal, VTEX, Shopify, Nuvemshop, etc.)
    const jsonLdScripts = document.querySelectorAll('script[type="application/ld+json"]');
    const ldCandidates = [];
    for (const script of jsonLdScripts) {
      try {
        const text = script.textContent;
        if (!text || !text.includes('Product')) continue;
        const parsed = JSON.parse(text);
        if (Array.isArray(parsed)) {
          ldCandidates.push(...parsed);
        } else if (parsed && typeof parsed === 'object') {
          if (Array.isArray(parsed['@graph'])) {
            ldCandidates.push(...parsed['@graph']);
          } else {
            ldCandidates.push(parsed);
          }
        }
      } catch {}
    }

    for (const item of ldCandidates) {
      if (!item || typeof item !== 'object') continue;
      const type = item['@type'];
      const isProduct =
        type === 'Product' ||
        type === 'IndividualProduct' ||
        type === 'ProductGroup' ||
        (Array.isArray(type) && type.includes('Product'));

      if (isProduct) {
        if (!title && item.name) title = String(item.name).trim();
        if (!title && item.headline) title = String(item.headline).trim();

        // Extrai imagens do produto
        const imgField = item.image;
        if (imgField) {
          if (Array.isArray(imgField)) {
            for (const img of imgField) {
              if (typeof img === 'string') addImage(img);
              else if (img && typeof img === 'object') addImage(img.url || img.contentUrl);
            }
          } else if (typeof imgField === 'object') {
            addImage(imgField.url || imgField.contentUrl);
          } else if (typeof imgField === 'string') {
            addImage(imgField);
          }
        }

        // Extrai ofertas/preço
        const offers = Array.isArray(item.offers) ? item.offers : item.offers ? [item.offers] : [];
        for (const offer of offers) {
          if (!offer) continue;
          if (offer.image) {
            if (typeof offer.image === 'string') addImage(offer.image);
            else if (offer.image.url) addImage(offer.image.url);
          }
          const rawP = offer.price ?? offer.lowPrice ?? offer.priceSpecification?.price;
          if (rawP !== undefined && rawP !== null && price === null) {
            const p = parseFloat(String(rawP).replace(',', '.'));
            if (!isNaN(p) && p > 0) price = p;
          }
          const rawHigh = offer.highPrice ?? offer.priceSpecification?.maxPrice;
          if (rawHigh !== undefined && rawHigh !== null && originalPrice === null) {
            const hp = parseFloat(String(rawHigh).replace(',', '.'));
            if (!isNaN(hp) && hp > 0) originalPrice = hp;
          }
        }
      }
    }

    // 2. Título via DOM / Meta tags se ainda não encontrado
    if (!title) {
      const h1 = document.querySelector(
        'h1.vtex-store-components-3-x-productNameContainer, h1[class*="product-name"], h1[class*="productName"], h1[class*="title"], h1[data-testid*="title"], h1',
      );
      if (h1 && h1.textContent.trim()) {
        title = h1.textContent.trim();
      }
    }
    if (!title) {
      const ogTitle =
        document.querySelector('meta[property="og:title"]')?.getAttribute('content') ||
        document.querySelector('meta[name="twitter:title"]')?.getAttribute('content');
      if (ogTitle) title = ogTitle.trim();
    }
    if (!title) {
      title = document.title;
    }

    // 3. Imagens via Meta tags (OpenGraph, Twitter, itemprop, link)
    if (images.length === 0) {
      const metaImages = [
        document.querySelector('meta[property="og:image:secure_url"]')?.getAttribute('content'),
        document.querySelector('meta[property="og:image"]')?.getAttribute('content'),
        document.querySelector('meta[name="twitter:image"]')?.getAttribute('content'),
        document.querySelector('meta[name="twitter:image:src"]')?.getAttribute('content'),
        document.querySelector('meta[itemprop="image"]')?.getAttribute('content'),
        document.querySelector('link[rel="image_src"]')?.getAttribute('href'),
        document.querySelector('link[rel="preload"][as="image"]')?.getAttribute('href'),
      ];
      for (const mImg of metaImages) {
        if (mImg) addImage(mImg);
      }
    }

    // 4. Imagens via seletores comuns de galeria / PDP de e-commerces parceiros
    if (images.length === 0) {
      const gallerySelectors = [
        '.vtex-store-components-3-x-productImageTag',
        '[data-testid*="product-image"] img',
        '[data-testid*="main-image"] img',
        '[class*="productImage"] img',
        '[class*="product-image"] img',
        '[class*="product__image"] img',
        '[class*="product-photo"] img',
        '[class*="gallery"] img',
        '[class*="carousel"] img',
        '[class*="slider"] img',
        '[class*="zoom"] img',
        '[class*="main-image"] img',
      ];
      for (const sel of gallerySelectors) {
        const els = document.querySelectorAll(sel);
        for (const el of els) {
          const src =
            el.getAttribute('data-zoom-image') ||
            el.getAttribute('data-large') ||
            el.getAttribute('data-src') ||
            el.getAttribute('data-original') ||
            el.currentSrc ||
            el.getAttribute('src');
          if (src) addImage(src);
        }
        if (images.length > 0) break;
      }
    }

    // 5. Heurística DOM universal para imagens: encontra a maior imagem visível de produto
    if (images.length === 0) {
      const allImgs = Array.from(document.querySelectorAll('img'));
      const ranked = [];
      for (const el of allImgs) {
        const src =
          el.getAttribute('data-zoom-image') ||
          el.getAttribute('data-large') ||
          el.getAttribute('data-src') ||
          el.currentSrc ||
          el.src;
        const abs = toAbsUrl(src);
        if (!abs || !abs.startsWith('http')) continue;
        if (/logo|icon|badge|avatar|flag|payment|bandeira|selo|sprite|footer|header|pixel|transp/i.test(abs)) continue;
        if (/logo|icon|badge|avatar/i.test(el.className || '')) continue;
        const w = el.naturalWidth || el.clientWidth || el.width || 0;
        const h = el.naturalHeight || el.clientHeight || el.height || 0;
        if (w >= 100 && h >= 100) {
          ranked.push({ src: abs, area: w * h });
        }
      }
      ranked.sort((a, b) => b.area - a.area);
      for (const item of ranked) {
        addImage(item.src);
      }
    }

    // 6. Preço via Meta tags se não veio do Schema.org
    if (!price) {
      const metaP =
        document.querySelector('meta[property="product:price:amount"]')?.getAttribute('content') ||
        document.querySelector('meta[property="og:price:amount"]')?.getAttribute('content') ||
        document.querySelector('meta[itemprop="price"]')?.getAttribute('content') ||
        document.querySelector('meta[name="twitter:data1"]')?.getAttribute('content');
      if (metaP) {
        const cleaned = metaP.replace(/[^\d.,]/g, '').replace(',', '.');
        const p = parseFloat(cleaned);
        if (!isNaN(p) && p > 0) price = p;
      }
    }

    // 7. Preço via Seletores DOM da Drogal / VTEX e similares
    if (!price) {
      const priceSelectors = [
        '.vtex-product-price-1-x-sellingPriceValue',
        '.vtex-product-price-1-x-spotPriceValue',
        '.skuBestPrice',
        '[class*="selling-price"]',
        '[class*="sellingPrice"]',
        '[class*="best-price"]',
        '[class*="bestPrice"]',
        '[class*="product-price"]',
        '[class*="productPrice"]',
        '[data-testid*="price"]',
        '[class*="price-sales"]',
        '[class*="price-box"]',
      ];
      for (const sel of priceSelectors) {
        const priceEl = document.querySelector(sel);
        if (priceEl && priceEl.textContent) {
          const match =
            priceEl.textContent.match(/R\$\s*([\d.]+,\d{2})/i) ||
            priceEl.textContent.match(/([\d.]+,\d{2})/);
          if (match) {
            const p = parseFloat(match[1].replace(/\./g, '').replace(',', '.'));
            if (!isNaN(p) && p > 0) {
              price = p;
              break;
            }
          }
        }
      }
    }

    // 8. Preço Original (riscado)
    if (!originalPrice) {
      const listPriceSelectors = [
        '.vtex-product-price-1-x-listPriceValue',
        '.skuListPrice',
        's',
        'del',
        '[class*="list-price"]',
        '[class*="listPrice"]',
        '[class*="original-price"]',
        '[class*="was-price"]',
        '[class*="price-from"]',
      ];
      for (const sel of listPriceSelectors) {
        const listPriceEl = document.querySelector(sel);
        if (listPriceEl && listPriceEl.textContent) {
          const match =
            listPriceEl.textContent.match(/R\$\s*([\d.]+,\d{2})/i) ||
            listPriceEl.textContent.match(/([\d.]+,\d{2})/);
          if (match) {
            const p = parseFloat(match[1].replace(/\./g, '').replace(',', '.'));
            if (!isNaN(p) && p > 0 && (!price || p > price)) {
              originalPrice = p;
              break;
            }
          }
        }
      }
    }

    let discountPct = null;
    if (originalPrice && price && originalPrice > price) {
      discountPct = Math.round(((originalPrice - price) / originalPrice) * 100);
    }

    couponCode = extractCouponFromScope(document.body, 'AWIN');

    return {
      title,
      price,
      originalPrice,
      discountPct,
      images,
      shipping: /frete gr[aá]tis/i.test(document.body.innerText) ? 'FREE' : 'UNKNOWN',
      couponCode,
    };
  }

  // Extrai metadados do DOM da página atual
  function extractProductFromPage() {
    const url = window.location.href;
    let title = document.title;
    let price = null;
    let originalPrice = null;
    let discountPct = null;
    let images = [];
    let shipping = 'UNKNOWN';
    let couponCode = null;

    // Mercado Livre
    if (url.includes('mercadolivre.com.br')) {
      const titleEl = document.querySelector('h1.ui-pdp-title') || document.querySelector('h1');
      if (titleEl) title = titleEl.textContent.trim();

      // 1. Preço Original (riscado / "de")
      const origEl = document.querySelector(
        '.ui-pdp-price__original-value, .andes-money-amount--previous, s .andes-money-amount, del .andes-money-amount, .ui-pdp-price__subtitles .andes-money-amount, s, del',
      );
      const parsedOrig = parseAndesMoney(origEl);
      if (parsedOrig) originalPrice = parsedOrig;

      // 2. Preço Atual (com escopo restrito ao elemento que não é o original)
      let currentPriceEl = document.querySelector('.ui-pdp-price__second-line');
      if (!currentPriceEl || !currentPriceEl.querySelector('.andes-money-amount__fraction')) {
        currentPriceEl =
          document.querySelector(
            '.ui-pdp-price__price .andes-money-amount:not(.andes-money-amount--previous), .ui-pdp-price__main-container .andes-money-amount:not(.andes-money-amount--previous):not(s *):not(del *)',
          ) ||
          Array.from(document.querySelectorAll('.andes-money-amount')).find(
            (el) =>
              !el.closest('s, del, .ui-pdp-price__original-value, .andes-money-amount--previous'),
          );
      }

      const parsedPrice = parseAndesMoney(currentPriceEl);
      if (parsedPrice) {
        price = parsedPrice;
      } else {
        // Fallback meta tags de preço
        const metaPrice =
          document.querySelector('meta[itemprop="price"]')?.getAttribute('content') ||
          document.querySelector('meta[property="product:price:amount"]')?.getAttribute('content');
        if (metaPrice) {
          const p = parseFloat(metaPrice);
          if (!isNaN(p) && p > 0) price = p;
        }
      }

      // Se o original for menor ou igual ao preço atual, anula o original
      if (originalPrice && price && originalPrice <= price) {
        originalPrice = null;
      }

      // 3. Desconto %
      const discountEl = document.querySelector(
        '.ui-pdp-price__second-line .ui-pdp-price__discount, .ui-pdp-discount, .ui-pdp-price__discount',
      );
      if (discountEl) {
        const m = discountEl.textContent.match(/(\d+)%/);
        if (m) discountPct = parseInt(m[1], 10);
      }
      if (!discountPct && originalPrice && price && originalPrice > price) {
        discountPct = Math.round(((originalPrice - price) / originalPrice) * 100);
      }

      // 4. Imagens
      // A galeria do ML repete a mesma foto em dois elementos: a miniatura da tira lateral
      // (`src` em baixa resolução) e a imagem grande em exibição (`data-zoom`, alta resolução).
      // Como ambos batem no seletor abaixo, priorizamos exclusivamente `data-zoom` quando existir
      // pelo menos um — senão a miniatura de baixa resolução acaba entrando como images[0].
      const imgElements = document.querySelectorAll(
        'img.ui-pdp-image, .ui-pdp-gallery__figure img, [data-zoom]',
      );
      const zoomImages = [];
      const srcImages = [];
      imgElements.forEach((img) => {
        const zoom = img.getAttribute('data-zoom');
        if (zoom && zoom.startsWith('http')) {
          if (!zoomImages.includes(zoom)) zoomImages.push(zoom);
          return;
        }
        const src = img.getAttribute('src') || img.getAttribute('data-src');
        if (src && src.startsWith('http') && !srcImages.includes(src)) {
          srcImages.push(src);
        }
      });
      images = zoomImages.length > 0 ? zoomImages : srcImages;
      if (images.length === 0) {
        const ogImage = document
          .querySelector('meta[property="og:image"]')
          ?.getAttribute('content');
        if (ogImage && ogImage.startsWith('http')) images.push(ogImage);
      }

      // 5. Frete e FULL
      if (
        document.querySelector(
          'svg.ui-pdp-icon--full, [class*="ui-pdp-icon--full"], [class*="full"]',
        )
      ) {
        shipping = 'FULL';
      } else if (/frete grátis/i.test(document.body.innerText)) {
        shipping = 'FREE';
      }

      // 6. Cupom
      couponCode = extractCouponFromScope(document, 'MERCADOLIVRE');
    }

    // Amazon
    else if (url.includes('amazon.com.br')) {
      const titleEl = document.querySelector('#productTitle') || document.querySelector('#title');
      if (titleEl) title = titleEl.textContent.trim();

      const offscreen = document.querySelector(
        '#corePrice_feature_div .a-price .a-offscreen, #apexPriceToPay .a-price .a-offscreen, .a-price.priceToPay .a-offscreen, #priceblock_ourprice',
      );
      if (offscreen) {
        const cleaned = offscreen.textContent.replace(/[^\d,]/g, '').replace(',', '.');
        const parsed = parseFloat(cleaned);
        if (!isNaN(parsed)) price = parsed;
      }

      const basisOffscreen = document.querySelector(
        '#basisPrice .a-offscreen, .a-price.a-text-price .a-offscreen, #listPrice .a-offscreen',
      );
      if (basisOffscreen) {
        const cleaned = basisOffscreen.textContent.replace(/[^\d,]/g, '').replace(',', '.');
        const parsed = parseFloat(cleaned);
        if (!isNaN(parsed)) originalPrice = parsed;
      }

      const discountEl = document.querySelector(
        '.savingPriceOverride, .reinventPriceSavingsPercentageMargin',
      );
      if (discountEl) {
        const m = discountEl.textContent.match(/(\d+)%/);
        if (m) discountPct = parseInt(m[1], 10);
      }
      if (!discountPct && originalPrice && price && originalPrice > price) {
        discountPct = Math.round(((originalPrice - price) / originalPrice) * 100);
      }

      // `data-old-hires`/`data-a-dynamic-image` são preferidos por serem mais estáveis,
      // mas o `src` puro também é uma imagem válida da Amazon (mesmo quando o caminho
      // contém "MEASUREMENT" — é só o nome do bucket de teste A/B da Amazon, não indica
      // formato quebrado) e não deve ser descartado.
      const imgEl = document.querySelector('#landingImage, #imgBlkFront, #main-image-container img');
      if (imgEl) {
        const best = extractBestUrlFromImg(imgEl);
        if (best) images.push(best);
      }
      if (images.length === 0) {
        const ogImage = document
          .querySelector('meta[property="og:image"]')
          ?.getAttribute('content');
        const upgradedOg = normalizeAndUpgradeImageUrl(ogImage);
        if (upgradedOg && !isBadProductImageUrl(upgradedOg)) images.push(upgradedOg);
      }

      if (document.querySelector('.a-icon-prime, #primeSavingsUpsell')) shipping = 'FREE';
      else if (/frete grátis/i.test(document.body.innerText)) shipping = 'FREE';

      // 6. Cupom Amazon (sem valor genérico fixo)
      couponCode = extractCouponFromScope(document, 'AMAZON');
    }

    // Magalu
    else if (url.includes('magazineluiza.com.br') || url.includes('magazinevoce.com.br')) {
      const titleEl =
        document.querySelector('[data-testid="heading-product-title"]') ||
        document.querySelector('h1.header-product__title') ||
        document.querySelector('h1');
      if (titleEl) title = titleEl.textContent.trim();

      const priceEl = document.querySelector(
        '[data-testid="price-value"], [data-testid="price-default"], .price-template__text, [data-testid="price-best"]',
      );
      if (priceEl) {
        const cleaned = priceEl.textContent.replace(/[^\d,]/g, '').replace(',', '.');
        const parsed = parseFloat(cleaned);
        if (!isNaN(parsed)) price = parsed;
      }

      const origEl = document.querySelector(
        '[data-testid="price-original"], [data-testid="price-from"], .price-template__from',
      );
      if (origEl) {
        const cleaned = origEl.textContent.replace(/[^\d,]/g, '').replace(',', '.');
        const parsed = parseFloat(cleaned);
        if (!isNaN(parsed)) originalPrice = parsed;
      }

      const discountEl = document.querySelector('[data-testid="price-discount"], .discount-tag');
      if (discountEl) {
        const m = discountEl.textContent.match(/(\d+)%/);
        if (m) discountPct = parseInt(m[1], 10);
      }
      if (!discountPct && originalPrice && price && originalPrice > price) {
        discountPct = Math.round(((originalPrice - price) / originalPrice) * 100);
      }

      const imgCandidate = document.querySelector(
        '[data-testid="main-image"] img, [data-testid="main-image"], [data-testid="media-gallery"] img, [data-testid="image-selected-thumbnail"] img, [data-testid="image-selected-thumbnail"], img.image-gallery-image',
      );
      const imgEl =
        imgCandidate && imgCandidate.tagName !== 'IMG'
          ? imgCandidate.querySelector('img')
          : imgCandidate;
      if (imgEl) {
        const best = extractBestUrlFromImg(imgEl);
        if (best) images.push(best);
      }
      if (images.length === 0) {
        const ogImage = document
          .querySelector('meta[property="og:image"]')
          ?.getAttribute('content');
        const upgradedOg = normalizeAndUpgradeImageUrl(ogImage);
        if (upgradedOg && !isBadProductImageUrl(upgradedOg)) images.push(upgradedOg);
      }

      if (/frete grátis|retira rápido|retira grátis/i.test(document.body.innerText))
        shipping = 'FREE';

      // 6. Cupom Magalu
      couponCode = extractCouponFromScope(document, 'MAGALU');
    }

    // Shopee
    else if (url.includes('shopee.com.br')) {
      const titleEl = document.querySelector('.WBAln7, .V37x3t, h1, [class*="product-title"]');
      if (titleEl) title = titleEl.textContent.trim();

      const priceEl = document.querySelector('.G27fpf, .pqTWkA, [class*="product-price"]');
      if (priceEl) {
        const cleaned = priceEl.textContent.replace(/[^\d,]/g, '').replace(',', '.');
        const parsed = parseFloat(cleaned);
        if (!isNaN(parsed)) price = parsed;
      }

      const origEl = document.querySelector('.k25aG1, .NZkL9r, [class*="original-price"]');
      if (origEl) {
        const cleaned = origEl.textContent.replace(/[^\d,]/g, '').replace(',', '.');
        const parsed = parseFloat(cleaned);
        if (!isNaN(parsed)) originalPrice = parsed;
      }

      const imgEl = document.querySelector(
        'img._11-H3t, img.pointer, [class*="product-image"] img',
      );
      if (imgEl) {
        const best = extractBestUrlFromImg(imgEl);
        if (best) images.push(best);
      }

      if (/frete grátis/i.test(document.body.innerText)) shipping = 'FREE';

      // 6. Cupom Shopee
      couponCode = extractCouponFromScope(document, 'SHOPEE');
    }

    // AliExpress
    // Classes CSS-módulo com sufixo hash (ex.: "price-default--current--F8OlYIo") — a Aliexpress
    // troca o hash a cada build, então usamos seletor por prefixo ([class*=...]) para resistir a
    // isso. Não existe h1 de produto de verdade (o único <h1> da página é fixo "Aliexpress"), o
    // título real fica em [class*="title--wrap"] (com fallback pro meta og:title).
    else if (url.includes('aliexpress.com')) {
      // 1. Em páginas SSR / Bundle Deals ou listagens, ao clicar num produto o AliExpress abre
      // um modal (.comet-v2-modal-wrap) apensado ao final do DOM. Se houver modais, o ativo é o
      // último visível na pilha do DOM.
      const allModals = Array.from(
        document.querySelectorAll(
          '.comet-v2-modal-wrap, .cosmos-drawer-wrap, [class*="modal-wrap"], [class*="drawer-wrap"], [class*="pdp-mini-wrap"], [class*="mini--wrap"]',
        ),
      ).filter((m) => {
        const style = window.getComputedStyle(m);
        const rect = m.getBoundingClientRect();
        return (
          style.display !== 'none' &&
          style.visibility !== 'hidden' &&
          style.opacity !== '0' &&
          rect.width > 100 &&
          rect.height > 100 &&
          m.querySelector('[class*="title--wrap"], [class*="price-default--current"]')
        );
      });

      const activeModal = allModals.length > 0 ? allModals[allModals.length - 1] : null;
      const scope = activeModal || document;

      const titleEl = scope.querySelector('[class*="title--wrap"]');
      if (titleEl) {
        title = titleEl.textContent.trim();
      } else if (!activeModal) {
        const ogTitle = document
          .querySelector('meta[property="og:title"]')
          ?.getAttribute('content');
        if (ogTitle) title = ogTitle.replace(/\s*-\s*AliExpress.*$/i, '').trim();
      }

      const priceEl = scope.querySelector('[class*="price-default--current"]');
      if (priceEl) {
        const cleaned = priceEl.textContent.replace(/[^\d,]/g, '').replace(',', '.');
        const parsed = parseFloat(cleaned);
        if (!isNaN(parsed)) price = parsed;
      }

      const origEl = scope.querySelector('[class*="price-default--original"]');
      if (origEl) {
        const cleaned = origEl.textContent.replace(/[^\d,]/g, '').replace(',', '.');
        const parsed = parseFloat(cleaned);
        if (!isNaN(parsed)) originalPrice = parsed;
      }

      const discountEl = scope.querySelector('[class*="price-default--discount"]');
      if (discountEl) {
        const m = discountEl.textContent.match(/(\d+)%/);
        if (m) discountPct = parseInt(m[1], 10);
      }
      if (!discountPct && originalPrice && price && originalPrice > price) {
        discountPct = Math.round(((originalPrice - price) / originalPrice) * 100);
      }

      // 2. Extração de imagem do produto ativo no escopo
      // Prioridade 1: Galeria ativa do escopo (magnifier, slider ativo, preview da esquerda)
      const galleryImg = scope.querySelector(
        '[class*="magnifier--image"], [class*="slider--active"] img, [class*="slider--img"] img, [class*="image-view"] img, [class*="gallery"] img, [class*="pdp-mini-info-left"] img, [class*="pdp-info-left"] img, [class*="main-image"] img',
      );
      if (galleryImg) {
        const best = extractBestUrlFromImg(galleryImg);
        if (best) images.push(best);
      }

      // Prioridade 2: Foto da variação de SKU selecionada no modal/página
      if (images.length === 0) {
        const skuImg = scope.querySelector(
          '[class*="sku-item--selected"] img, [class*="sku--selected"] img, [class*="skuItem--selected"] img',
        );
        if (skuImg) {
          const best = extractBestUrlFromImg(skuImg);
          if (best) images.push(best);
        }
      }

      // Prioridade 3: Meta tag og:image (apenas se não for modal e se não for ícone genérico)
      if (images.length === 0 && !activeModal) {
        const ogImage = document
          .querySelector('meta[property="og:image"]')
          ?.getAttribute('content');
        const isGenericOgImage =
          ogImage &&
          (ogImage.includes('HTB18eCBQXXXXXXfXXXX760XFXXXa') ||
            ogImage.includes('logo') ||
            ogImage.includes('icon'));
        const upgradedOg = normalizeAndUpgradeImageUrl(ogImage);
        if (upgradedOg && !isBadProductImageUrl(upgradedOg) && !isGenericOgImage) {
          images.push(upgradedOg);
        }
      }

      // Prioridade 4: Seletor de card no escopo (para páginas estáticas de bundle)
      if (images.length === 0) {
        const cardImg = scope.querySelector(
          'img.AIC-MI-img, [class*="AIC-MI-container"] img, [class*="productContainer"] img, [class*="productSliderList"] img, [class*="product-img"] img, [class*="product-image"] img, [class*="detail-gallery"] img, [class*="item-image"] img',
        );
        if (cardImg) {
          const best = extractBestUrlFromImg(cardImg);
          if (best) images.push(best);
        }
      }

      if (/frete gr[aá]tis/i.test(document.body.innerText)) shipping = 'FREE';

      // 6. Cupom AliExpress
      couponCode = extractCouponFromScope(scope, 'ALIEXPRESS');
    }

    // 7. Parceiros AWIN (ex: Drogal BR e outras lojas parceiras)
    if (
      !url.includes('mercadolivre.com.br') &&
      !url.includes('amazon.com.br') &&
      !url.includes('magazineluiza.com.br') &&
      !url.includes('magazinevoce.com.br') &&
      !url.includes('shopee.com.br') &&
      !url.includes('aliexpress.com')
    ) {
      const awinData = extractProductFromAwinPartner();
      if (awinData.title) title = awinData.title;
      if (awinData.price) price = awinData.price;
      if (awinData.originalPrice) originalPrice = awinData.originalPrice;
      if (awinData.discountPct) discountPct = awinData.discountPct;
      if (awinData.images && awinData.images.length > 0) images = awinData.images;
      if (awinData.shipping) shipping = awinData.shipping;
      if (awinData.couponCode) couponCode = awinData.couponCode;
    }

    return {
      title,
      price,
      originalPrice,
      discountPct,
      images,
      shipping,
      couponCode,
    };
  }

  // Reconhece URLs de produto nos 4 marketplaces suportados (mesmos padrões de
  // packages/core/src/urls.ts#parseProductUrl, duplicados aqui porque a extensão
  // roda como content script puro, sem acesso ao pacote TS do monorepo).
  function isProductUrl(raw) {
    let u;
    try {
      u = new URL(raw);
    } catch {
      return false;
    }
    const host = u.hostname.replace(/^www\./, '');
    const path = u.pathname;
    if (host === 'shopee.com.br') {
      return /-i\.(\d+)\.(\d+)/.test(path) || /^\/product\/(\d+)\/(\d+)/.test(path);
    }
    if (
      host === 'shp.ee' ||
      host.endsWith('.shp.ee') ||
      host === 'shope.ee' ||
      host.endsWith('.shope.ee')
    ) {
      return true;
    }
    if (host === 'mercadolivre.com.br' || host.endsWith('.mercadolivre.com.br')) {
      return (
        /MLB[U]?-?(\d+)/i.test(path) ||
        /\/p\/(MLB\d+|[A-Z0-9]+)/i.test(path) ||
        /\/up\/(MLBU?\d+|[A-Z0-9]+)/i.test(path) ||
        /[?&]pdp_filters=.*item_id(?:%3A|:)MLB/i.test(u.search)
      );
    }
    if (host === 'meli.la') {
      return true;
    }
    if (host === 'amazon.com.br') {
      return /\/(?:dp|gp\/product|product)\/([A-Z0-9]{10})/.test(path);
    }
    if (
      host === 'magazineluiza.com.br' ||
      host === 'magazinevoce.com.br' ||
      host.endsWith('.magazinevoce.com.br')
    ) {
      // O fallback sem "/p/" exige ao menos 1 dígito no segmento: slugs de navegação
      // (/informatica/, /favoritos/) são só letras e batiam no padrão antigo, virando
      // falsos positivos na captura em lote.
      return /\/p\/([a-z0-9]+)/i.test(path) || /\/([a-z0-9]*\d[a-z0-9]{6,11})\//i.test(path);
    }
    if (host === 'aliexpress.com' || host.endsWith('.aliexpress.com')) {
      return /\/item\/(\d+)/i.test(path) || /_p(\d+)/i.test(path);
    }
    // Parceiros AWIN ou e-commerces universais (Drogal, VTEX, Dafiti, Centauro, etc.)
    if (
      /\/p(\?|$|\/)/i.test(path) ||
      /\/produto[\/-]/i.test(path) ||
      /\/pdp[\/-]/i.test(path) ||
      /\/item[\/-]/i.test(path) ||
      /\/(?:dp|d)\/[A-Z0-9]+/i.test(path) ||
      /\.html?$/i.test(path)
    ) {
      return true;
    }
    return false;
  }

  // Desembrulha proxies de imagem (ex: /_next/image?url=...) e troca URLs de miniatura
  // por versões em alta resolução nos CDNs dos marketplaces suportados (Magalu, Amazon,
  // Shopee, AliExpress).
  function normalizeAndUpgradeImageUrl(rawUrl) {
    if (!rawUrl || typeof rawUrl !== 'string') return null;
    let url = rawUrl.trim();
    if (!url || url.startsWith('data:') || url.startsWith('blob:')) return null;
    if (url.startsWith('//')) url = `https:${url}`;
    if (!url.startsWith('http://') && !url.startsWith('https://')) {
      try {
        url = new URL(url, window.location.href).toString();
      } catch {
        return null;
      }
    }

    // Next.js Image Optimization proxy (comum no Magalu e parceiros): extrai a URL original
    try {
      const parsed = new URL(url);
      if (parsed.pathname === '/_next/image' && parsed.searchParams.get('url')) {
        const inner = parsed.searchParams.get('url').trim();
        if (inner.startsWith('//')) url = `https:${inner}`;
        else if (inner.startsWith('http://') || inner.startsWith('https://')) url = inner;
        else if (inner.startsWith('/')) url = new URL(inner, parsed.origin).toString();
      }
    } catch {}

    // Magalu (mlcdn): troca /LxA/ (ex: /200x200/, /280x210/) por /1500x1500/
    if (/\.mlcdn\.com\.br\//i.test(url)) {
      url = url.replace(/(\.mlcdn\.com\.br\/(?:fit-in\/)?)\d+x\d+\//i, '$11500x1500/');
    }

    // Amazon (media-amazon / ssl-images-amazon): troca modificador de miniatura
    // (ex: ._AC_UL320_.jpg, ._AC_SR160,160_.jpg, ._SS40_.jpg) por ._AC_SL1500_.
    if (/(?:media-amazon\.com|ssl-images-amazon\.com|images-amazon\.com)\/images\/[IP]\//i.test(url)) {
      url = url.replace(
        /(\/images\/[IP]\/[^/?#]+?)\._[^/]+_\.(jpe?g|png|webp)(\?.*)?$/i,
        '$1._AC_SL1500_.$2$3',
      );
    }

    // Shopee: remove sufixo _tn de miniatura
    if (/susercontent\.com|shopee\.com\.br/i.test(url)) {
      url = url.replace(/_tn(\.(?:jpe?g|png|webp))?(\?.*)?$/i, '$1$2');
    }

    // AliExpress: remove sufixo _LxA após a extensão real
    if (/alicdn\.com/i.test(url)) {
      url = url.replace(/\.(jpe?g|png|webp)_\d+x\d+[^/?#]*(\?.*)?$/i, '.$1$2');
    }

    return url;
  }

  function isBadProductImageUrl(url) {
    if (!url || typeof url !== 'string') return true;
    if (!/^https?:\/\//i.test(url)) return true;
    // Assets de UI da Amazon (selos Prime, estrelas, pixels transparentes) ficam em /images/G/
    if (/(?:media-amazon\.com|ssl-images-amazon\.com|images-amazon\.com)\/images\/G\//i.test(url)) {
      return true;
    }
    return /(?:transparent-pixel|grey-pixel|1x1|spacer|placeholder|loading|spinner|evaluate|avatar|stars|rating|sprite|favicon|prime-logo|prime_badge|selo-|bandeira)/i.test(
      url,
    );
  }

  // Escolhe a maior resolução em um srcset / data-srcset sem quebrar URLs que contêm
  // vírgula nos parâmetros (ex: Amazon ._AC_SR160,160_.jpg).
  function parseSrcsetBest(srcset) {
    if (!srcset || typeof srcset !== 'string') return null;
    const entries = srcset.trim().split(/,\s+(?=\S)/);
    let bestUrl = null;
    let bestScore = -1;
    for (const entry of entries) {
      const parts = entry.trim().split(/\s+/);
      const rawUrl = parts[0];
      if (!rawUrl || rawUrl.startsWith('data:') || rawUrl.startsWith('blob:')) continue;
      let score = 1;
      const desc = parts[1];
      if (desc) {
        const num = parseFloat(desc);
        if (!isNaN(num)) {
          score = desc.endsWith('w') ? num : desc.endsWith('x') ? num * 1000 : num;
        }
      }
      if (score > bestScore) {
        bestScore = score;
        bestUrl = rawUrl;
      }
    }
    return bestUrl;
  }

  function parseAmazonDynamicImageBest(raw) {
    if (!raw || typeof raw !== 'string') return null;
    try {
      const parsed = JSON.parse(raw);
      let bestUrl = null;
      let bestArea = -1;
      for (const [u, dims] of Object.entries(parsed)) {
        if (!u || !u.startsWith('http')) continue;
        const area = Array.isArray(dims) && dims.length >= 2 ? Number(dims[0]) * Number(dims[1]) : 0;
        if (area > bestArea) {
          bestArea = area;
          bestUrl = u;
        }
      }
      return bestUrl;
    } catch {
      return null;
    }
  }

  // Extrai a melhor URL de um elemento <img> priorizando atributos de alta resolução e
  // lazy-load (data-old-hires, data-zoom, data-a-dynamic-image, srcset, data-src) antes do
  // `src` padrão (que frequentemente traz só um preview borrado ou placeholder).
  function extractBestUrlFromImg(img) {
    if (!img) return null;
    const candidates = [
      img.getAttribute('data-old-hires'),
      img.getAttribute('data-zoom-image'),
      img.getAttribute('data-zoom'),
      img.getAttribute('data-large'),
      parseAmazonDynamicImageBest(img.getAttribute('data-a-dynamic-image')),
    ];

    if (img.parentElement && img.parentElement.tagName === 'PICTURE') {
      const sources = img.parentElement.querySelectorAll('source');
      for (const source of sources) {
        const sBest = parseSrcsetBest(
          source.getAttribute('data-srcset') || source.getAttribute('srcset'),
        );
        if (sBest) candidates.push(sBest);
      }
    }

    const srcsetBest = parseSrcsetBest(
      img.getAttribute('data-srcset') || img.getAttribute('srcset'),
    );
    if (srcsetBest) candidates.push(srcsetBest);

    candidates.push(
      img.getAttribute('data-src'),
      img.getAttribute('data-original'),
      img.getAttribute('data-lazy-src'),
      img.getAttribute('data-lazy'),
      img.currentSrc,
      img.getAttribute('src'),
      img.src,
    );

    for (const raw of candidates) {
      const upgraded = normalizeAndUpgradeImageUrl(raw);
      if (upgraded && !isBadProductImageUrl(upgraded)) {
        return upgraded;
      }
    }
    return null;
  }

  // Helper para extrair a imagem principal de um container/card de produto em listagens,
  // ranqueando os <img> para evitar selos/swatches/ícones e priorizando alta resolução.
  function extractCardImage(container) {
    if (!container) return null;
    const imgEls = Array.from(container.querySelectorAll('img'));
    let bestUrl = null;
    let bestScore = -1;

    for (const img of imgEls) {
      const cls = `${img.className || ''} ${img.id || ''}`;
      if (/(?:badge|selo|swatch|stars|rating|avatar|logo|prime|flag)/i.test(cls)) continue;

      const attrW = parseInt(img.getAttribute('width') || '', 10);
      const attrH = parseInt(img.getAttribute('height') || '', 10);
      if ((!isNaN(attrW) && attrW > 0 && attrW < 40) || (!isNaN(attrH) && attrH > 0 && attrH < 40)) {
        continue;
      }

      const rect = typeof img.getBoundingClientRect === 'function' ? img.getBoundingClientRect() : null;
      const rw = rect ? rect.width : img.clientWidth || 0;
      const rh = rect ? rect.height : img.clientHeight || 0;
      if (rw > 0 && rw < 40 && rh > 0 && rh < 40) continue;

      const url = extractBestUrlFromImg(img);
      if (!url) continue;

      let score = 0;
      if (
        img.matches?.(
          'img.s-image, [data-testid="image"], [data-testid*="product-image"] img, .ui-search-result-image__element, .poly-component__picture, .dcl-product-image-container img',
        )
      ) {
        score += 1_000_000;
      }
      const area = rw > 0 && rh > 0 ? rw * rh : (img.naturalWidth || 0) * (img.naturalHeight || 0);
      score += area;

      if (score > bestScore) {
        bestScore = score;
        bestUrl = url;
      }
    }
    return bestUrl;
  }

  // Extrai preço/preço original de um card usando seletores estruturados específicos do
  // marketplace atual (mais confiável que regex de texto, que pega parcelamento, "economize
  // R$X" etc). Retorna null se o marketplace não tiver seletores conhecidos, sinalizando que
  // o chamador deve cair no fallback de regex genérica.
  function extractCardPrice(container) {
    const url = window.location.href;

    if (url.includes('amazon.com.br')) {
      // Preço atual: qualquer .a-price que NÃO seja o preço de lista/tachado (a-text-price)
      const currentEl = Array.from(
        container.querySelectorAll('.a-price:not(.a-text-price) .a-offscreen'),
      ).find((el) => !el.closest('.a-text-price'));
      // Preço original: preço de lista/tachado
      const origEl = container.querySelector(
        '.a-price.a-text-price .a-offscreen, .basisPrice .a-offscreen',
      );

      let price;
      let originalPrice;
      if (currentEl) {
        const p = parseFloat(currentEl.textContent.replace(/[^\d,]/g, '').replace(',', '.'));
        if (!isNaN(p) && p > 0) price = p;
      }
      if (origEl) {
        const p = parseFloat(origEl.textContent.replace(/[^\d,]/g, '').replace(',', '.'));
        if (!isNaN(p) && p > 0) originalPrice = p;
      }

      if (price === undefined) return null;
      return { price, originalPrice };
    }

    if (url.includes('mercadolivre.com.br')) {
      // Preço atual: dentro de .poly-price__current (exclui parcelamento e cupom, que ficam
      // em containers irmãos fora dele)
      const currentFracEl = container.querySelector(
        '.poly-price__current .andes-money-amount__fraction',
      );
      const currentCentsEl = container.querySelector(
        '.poly-price__current .andes-money-amount__cents',
      );
      // Preço original ("De:"): dentro de .poly-price__labels, sempre marcado com --previous
      const origFracEl = container.querySelector(
        '.poly-price__labels .andes-money-amount--previous .andes-money-amount__fraction',
      );
      const origCentsEl = container.querySelector(
        '.poly-price__labels .andes-money-amount--previous .andes-money-amount__cents',
      );

      let price;
      let originalPrice;
      if (currentFracEl) {
        const frac = currentFracEl.textContent.replace(/\./g, '').trim();
        const cents = currentCentsEl ? currentCentsEl.textContent.trim() : null;
        const p = parseFloat(frac + (cents ? `.${cents}` : ''));
        if (!isNaN(p) && p > 0) price = p;
      }
      if (origFracEl) {
        const frac = origFracEl.textContent.replace(/\./g, '').trim();
        const cents = origCentsEl ? origCentsEl.textContent.trim() : null;
        const p = parseFloat(frac + (cents ? `.${cents}` : ''));
        if (!isNaN(p) && p > 0) originalPrice = p;
      }

      if (price === undefined) return null;
      return { price, originalPrice };
    }

    if (url.includes('magazineluiza.com.br') || url.includes('magazinevoce.com.br')) {
      // Não há preço riscado tradicional nos cards: o preço à vista/Pix fica em
      // product-card-price-final, e o preço cheio aparece embutido no texto de
      // parcelamento ("Ou R$ 3.999,00 em 10x de R$ 399,90 sem juros") — extraído por
      // posição textual ("Ou R$X em"), não pela parcela em si.
      const finalEl = container.querySelector('[data-testid="product-card-price-final"]');
      const installmentEl = container.querySelector(
        '[data-testid="product-card-price-installment"]',
      );

      let price;
      let originalPrice;
      if (finalEl) {
        const integerEl = finalEl.querySelector('[data-testid="price-value-integer"]');
        const centsEl = finalEl.querySelector('[data-testid="price-value-split-cents-fraction"]');
        if (integerEl) {
          const intPart = integerEl.textContent.replace(/\./g, '').trim();
          const cents = centsEl ? centsEl.textContent.trim() : null;
          const p = parseFloat(intPart + (cents ? `.${cents}` : ''));
          if (!isNaN(p) && p > 0) price = p;
        }
      }
      if (installmentEl) {
        const m = (installmentEl.textContent || '').match(/Ou\s+R\$\s?([\d.,]+)\s+em/i);
        if (m) {
          const p = parseFloat(m[1].replace(/\./g, '').replace(',', '.'));
          if (!isNaN(p) && p > 0 && (!price || p > price)) originalPrice = p;
        }
      }

      if (price === undefined) return null;
      return { price, originalPrice };
    }

    if (url.includes('aliexpress.')) {
      // O texto dos cards do AliExpress não é confiável: os valores ficam colados em outros
      // textos ("R$1.999" + "524 vendido(s)" vira "R$1.999524") e a parcela vem como
      // "12 × R$165,75" / "12 parcelas de R$53,53", que escapam da limpeza do fallback.
      // O próprio link do card traz os preços no parâmetro pdp_npi, no formato
      // "6@dis!BRL!<preço cheio>!<preço atual>!!!..." — lemos daí.
      const links = [];
      if (container.matches?.('a[href]')) links.push(container);
      links.push(...container.querySelectorAll('a[href*="pdp_npi"]'));
      for (const link of links) {
        let npi;
        try {
          npi = new URL(link.getAttribute('href'), window.location.href).searchParams.get(
            'pdp_npi',
          );
        } catch {
          continue;
        }
        if (!npi) continue;
        const parts = npi.split('!');
        const i = parts.indexOf('BRL');
        if (i < 0) continue;
        const orig = parseFloat(parts[i + 1]);
        const sale = parseFloat(parts[i + 2]);
        if (isNaN(sale) || sale <= 0) continue;
        return { price: sale, originalPrice: !isNaN(orig) && orig > sale ? orig : undefined };
      }
      return null;
    }

    return null;
  }

  // Varre todos os links da página atual e devolve, para cada URL de produto única, também
  // título/preço/imagem lidos do próprio card na página — funciona tanto numa página de
  // busca/listagem (dezenas de cards) quanto numa página de produto único (0 ou 1 link).
  // Extrair esses metadados aqui evita depender de o backend raspar cada URL depois (o que
  // para Mercado Livre/Magalu esbarra em bloqueio anti-bot e não retorna dados reais).
  function isPollutedCardElement(a) {
    const pollutedSelector = [
      '.AdHolder',
      '[data-component-type="sp-sponsored-result"]',
      '[cel_widget_id*="sp_"]',
      '[data-cel-widget*="rhf"]',
      '#rhf',
      '[data-cel-widget*="sims-"]',
      '[data-cel-widget*="percolate"]',
      '.s-shopping-ad',
      '[aria-label*="Patrocinado" i]',
      '.ui-recommendations-carousel',
      '[data-testid="recommendations"]',
      '.advertising',
    ].join(', ');
    if (a.closest(pollutedSelector)) return true;
    const href = a.getAttribute('href') || '';
    if (/click\d*\.mercadolivre/i.test(href)) return true;
    return false;
  }

  function extractProductsFromPage() {
    const seen = new Set();
    const seenContainers = new Set();
    const items = [];
    const hasMainAmazonGrid = Boolean(
      document.querySelector(
        '[data-component-type="s-search-result"][data-asin], [data-testid="product-card"]',
      ),
    );
    document.querySelectorAll('a[href]').forEach((a) => {
      if (items.length >= 200) return;
      if (isPollutedCardElement(a)) return;
      let absolute;
      try {
        absolute = new URL(a.getAttribute('href'), window.location.href).toString();
      } catch {
        return;
      }
      if (!isProductUrl(absolute)) return;
      // Dedup pela URL sem querystring: variações de cor/tamanho do mesmo produto
      // geram links com o mesmo path mas parâmetros diferentes (ex: pdp_filters=deal:MLBxxxx-1
      // no Mercado Livre, um por cor), e são o mesmo produto.
      let dedupeKey;
      try {
        const du = new URL(absolute);
        dedupeKey = du.origin + du.pathname;
      } catch {
        dedupeKey = absolute;
      }
      if (seen.has(dedupeKey)) return;
      seen.add(dedupeKey);

      // Sobe a partir do link até achar um container de card razoável.
      // Prioridade 1: alguns marketplaces marcam o card real com um data-testid/data-asin
      // estável — usamos isso direto quando existir, porque a heurística por contagem de
      // links abaixo pode falhar mesmo dentro do card correto (ex: card com seletor de cor
      // onde a âncora da imagem e a do título apontam para ASINs de variações diferentes).
      // Seletores exatos (não `*=`) para não bater com a própria âncora, que no Magalu tem
      // data-testid="product-card-link" (conteria "product-card" num match parcial).
      const structuralCard =
        a.closest(
          '[data-testid="product-card"], [data-testid="product-card-container"], [data-component-type="s-search-result"][data-asin]:not([data-asin=""]), .s-result-item[data-asin]:not([data-asin=""]), .dcl-product-wrapper, .ui-search-layout__item, .poly-card',
        ) || (hasMainAmazonGrid ? null : a.closest('[data-asin]:not([data-asin=""])'));

      // Prioridade 2 (fallback p/ marketplaces sem marcação estrutural): sobe até achar um
      // ancestral com imagem + valor em R$ (até 6 níveis), parando assim que o próximo
      // ancestral passaria a conter links de MAIS DE UM produto distinto — sinal de que já
      // saímos do card individual e entramos num wrapper de grade. Contamos produtos únicos
      // (por URL sem querystring), não links brutos: cards costumam ter 2 âncoras separadas
      // para o mesmo produto (uma envolvendo a imagem, outra o título/preço).
      let container = structuralCard || a;
      for (let i = 0; !structuralCard && i < 6 && container.parentElement; i++) {
        const next = container.parentElement;
        const productUrlsInNext = Array.from(next.querySelectorAll('a[href]'))
          .map((el) => {
            try {
              return new URL(el.getAttribute('href'), window.location.href).toString();
            } catch {
              return null;
            }
          })
          .filter((href) => href && isProductUrl(href));
        const uniqueProductsInNext = new Set(
          productUrlsInNext.map((href) => {
            try {
              const du = new URL(href);
              return du.origin + du.pathname;
            } catch {
              return href;
            }
          }),
        );
        if (uniqueProductsInNext.size > 1) break;
        container = next;
        if (container.querySelector('img') && /R\$\s?[\d.,]+/.test(container.textContent || '')) {
          break;
        }
      }

      // Dedup pelo container real (não só pela URL): links de swatch de cor (Branco, Preto...)
      // resolvem para ASINs diferentes mas para o MESMO card visual quando o card tem seletor
      // de variação — sem isso, cada swatch vira uma entrada fantasma duplicando o produto.
      if (seenContainers.has(container)) return;
      seenContainers.add(container);

      let price;
      let originalPrice;
      const structuredPrice = extractCardPrice(container);
      if (structuredPrice) {
        price = structuredPrice.price;
        originalPrice = structuredPrice.originalPrice;
      } else {
        // Fallback: regex genérica sobre o texto do card (marketplaces sem seletores
        // estruturados mapeados ainda, ex.: carrosséis de recomendação do Magalu). Antes de
        // escolher o menor valor como preço, remove o valor da parcela ("10x de R$ 55,44") e
        // de cupons ("R$ 300 OFF") — senão a parcela vira o preço e o preço vira o "original".
        const priceText = (container.textContent || '')
          .replace(/\d+\s*(?:[x×]|parcelas)\s*(?:de\s*)?R\$\s?[\d.,]+/gi, ' ')
          .replace(/R\$\s?[\d.,]+\s*(?:OFF|de\s+desconto)/gi, ' ');
        const priceMatches = Array.from(priceText.matchAll(/R\$\s?([\d.,]+)/g))
          .map((m) => parseFloat(m[1].replace(/\./g, '').replace(',', '.')))
          .filter((n) => !isNaN(n) && n > 0);
        if (priceMatches.length === 1) {
          price = priceMatches[0];
        } else if (priceMatches.length > 1) {
          price = Math.min(...priceMatches);
          const maxV = Math.max(...priceMatches);
          if (maxV > price) originalPrice = maxV;
        }
      }

      const image = extractCardImage(container);

      const primaryImg = container.querySelector('img');
      // Heading/testid de título dedicado (quando existir) é mais confiável que o alt da
      // imagem, que em alguns marketplaces (ex: Magalu) é um texto genérico tipo "Imagem
      // do produto" em vez do nome real.
      const titleEl = container.querySelector('h1, h2, h3, h4, [data-testid*="title" i]');
      let title =
        a.getAttribute('title') ||
        a.getAttribute('aria-label') ||
        titleEl?.textContent?.trim() ||
        primaryImg?.getAttribute('alt') ||
        (a.textContent || '').trim();
      if (title)
        title =
          title
            .replace(/R\$\s?[\d.,]+/g, '')
            .trim()
            .slice(0, 200) || undefined;

      items.push({
        url: absolute,
        ...(title ? { title } : {}),
        ...(price !== undefined ? { price } : {}),
        ...(originalPrice !== undefined ? { originalPrice } : {}),
        ...(image ? { images: [image] } : {}),
      });
    });
    return items;
  }

  // Botão flutuante para copiar todos os produtos da página atual (ex: uma página de busca
  // do Mercado Livre/Amazon/Magalu), com título/preço/imagem já lidos do card, para colar em
  // Buscar Produtos → Por Links/CSV no app — útil quando a busca automática do marketplace
  // não está disponível (bloqueio anti-bot, API sem acesso etc.).
  function injectCopyLinksButton() {
    if (document.getElementById('afilados-copy-links-btn')) return;

    const btn = document.createElement('button');
    btn.id = 'afilados-copy-links-btn';
    btn.className = 'afilados-float-btn afilados-float-btn--secondary';
    btn.innerHTML = '<span>🔗</span> Copiar links';
    btn.title = 'Copiar todos os produtos desta página para colar no Afilados';

    btn.addEventListener('click', async () => {
      // Descarta produtos sem preço válido (extração falhou ou é um item fantasma tipo
      // swatch de cor) — evita poluir a lista colada no app com itens que não servem
      // pra nada sem preço.
      const items = extractProductsFromPage().filter(
        (item) => typeof item.price === 'number' && !isNaN(item.price) && item.price > 0,
      );
      if (items.length === 0) {
        btn.innerHTML = '<span>—</span> Nenhum link';
        setTimeout(() => {
          btn.innerHTML = '<span>🔗</span> Copiar links';
        }, 2500);
        return;
      }
      try {
        await navigator.clipboard.writeText(JSON.stringify(items));
        btn.innerHTML = `<span>✓</span> ${items.length} produto(s) copiado(s)!`;
        btn.classList.add('success');
      } catch {
        btn.innerHTML = '<span>❌</span> Falha ao copiar';
      }
      setTimeout(() => {
        btn.innerHTML = '<span>🔗</span> Copiar links';
        btn.classList.remove('success');
      }, 3000);
    });

    getOrCreateFabWrapper().appendChild(btn);
  }

  // Responde a mensagens da extensão
  if (typeof chrome !== 'undefined' && chrome.runtime) {
    chrome.runtime.onMessage.addListener((req, sender, sendResponse) => {
      if (req.action === 'GET_PRODUCT_DATA') {
        const product = extractProductFromPage();
        sendResponse({ product });
      }
      // Descoberta em segundo plano: o background abre a busca numa aba, e aqui rolamos a
      // página para o lazy-load carregar os cards antes de ler título/preço/imagem de cada um.
      if (req.action === 'EXTRACT_PRODUCTS') {
        (async () => {
          for (let i = 0; i < 6; i++) {
            window.scrollBy(0, window.innerHeight);
            await new Promise((r) => setTimeout(r, 400));
          }
          window.scrollTo(0, 0);
          const items = extractProductsFromPage();
          const bodyText = document.body ? document.body.innerText : '';
          const html = document.documentElement.outerHTML;
          let diagnosis;
          if (items.length === 0) {
            if (/negative_traffic|account-verification|captcha|unusual traffic/i.test(html)) {
              diagnosis = 'verificação anti-bot detectada na página';
            } else if (bodyText.length < 1500) {
              diagnosis = `página não terminou de carregar (${bodyText.length} caracteres, aba ${document.visibilityState})`;
            } else {
              diagnosis = `página carregou (${bodyText.length} caracteres) mas nenhum card de produto foi reconhecido`;
            }
          }
          sendResponse({ items, title: document.title, diagnosis });
        })();
        return true; // resposta assíncrona
      }
    });
  }

  // Destino da captura escolhido no popup (`lastCaptureTarget` no chrome.storage):
  // { value: '' | 'rule:<id>' | 'batch:<id>', label }. Formato antigo: string com o id da automação.
  function parseCaptureTarget(saved) {
    const value =
      typeof saved === 'string' ? (saved ? `rule:${saved}` : '') : (saved && saved.value) || '';
    const label = (saved && typeof saved === 'object' && saved.label) || '';
    if (value.startsWith('batch:')) return { kind: 'batch', id: value.slice(6), label };
    if (value.startsWith('rule:')) return { kind: 'rule', id: value.slice(5), label };
    return { kind: 'triage', id: null, label: '' };
  }

  function captureTargetPayload(target) {
    if (target.kind === 'batch') return { batchId: target.id };
    if (target.kind === 'rule') return { automationRuleId: target.id };
    return {};
  }

  // Injeta botão flutuante na página
  function injectFloatingButton() {
    if (document.getElementById('afilados-floating-btn')) return;

    const btn = document.createElement('button');
    btn.id = 'afilados-floating-btn';
    btn.className = 'afilados-float-btn';
    btn.title = 'Capturar oferta para o Afilados';

    // O rótulo mostra o destino escolhido no popup quando ele não é a Triagem. O nome do
    // lote/automação vem do usuário, então entra por textContent (nunca innerHTML).
    let currentTarget = { kind: 'triage', id: null, label: '' };
    function setIdleLabel() {
      const icon = document.createElement('span');
      icon.textContent = '⚡';
      let text = ' Enviar Produto';
      if (currentTarget.kind !== 'triage' && currentTarget.label) {
        const name =
          currentTarget.label.length > 22
            ? `${currentTarget.label.slice(0, 21)}…`
            : currentTarget.label;
        text = ` Enviar → ${currentTarget.kind === 'batch' ? 'Lote ' : ''}${name}`;
      }
      btn.replaceChildren(icon, document.createTextNode(text));
    }
    setIdleLabel();
    if (chrome.storage) {
      chrome.storage.local.get(['lastCaptureTarget']).then((s) => {
        currentTarget = parseCaptureTarget(s.lastCaptureTarget);
        if (!btn.classList.contains('loading')) setIdleLabel();
      });
      chrome.storage.onChanged.addListener((changes, area) => {
        if (area !== 'local' || !changes.lastCaptureTarget) return;
        currentTarget = parseCaptureTarget(changes.lastCaptureTarget.newValue);
        if (!btn.classList.contains('loading')) setIdleLabel();
      });
    }

    btn.addEventListener('click', async () => {
      btn.innerHTML = '<span>⏳</span> Enviando...';
      btn.classList.add('loading');

      const saved = await chrome.storage.local.get(['apiUrl', 'apiToken', 'lastCaptureTarget']);
      currentTarget = parseCaptureTarget(saved.lastCaptureTarget);
      const apiUrl = (saved.apiUrl || 'http://localhost:3011').replace(/\/+$/, '');
      const apiToken = saved.apiToken;

      if (!apiToken) {
        alert('Afilados Connect: Configure seu Token de API abrindo o popup da extensão.');
        setIdleLabel();
        btn.classList.remove('loading');
        return;
      }

      const product = extractProductFromPage();
      const url = window.location.href;
      let marketplaceKind = 'SHOPEE';
      if (url.includes('mercadolivre.com.br')) marketplaceKind = 'MERCADOLIVRE';
      else if (url.includes('amazon.com.br')) marketplaceKind = 'AMAZON';
      else if (url.includes('magazineluiza.com.br') || url.includes('magazinevoce.com.br'))
        marketplaceKind = 'MAGALU';
      else if (url.includes('aliexpress.com')) marketplaceKind = 'ALIEXPRESS';
      else marketplaceKind = 'AWIN';

      let affiliateUrl = undefined;
      if (marketplaceKind === 'AWIN') {
        const { awinPartners, awinPublisherId } = await chrome.storage.local.get([
          'awinPartners',
          'awinPublisherId',
        ]);
        const host = window.location.hostname.replace(/^www\./, '').toLowerCase();
        let partner = awinPartners && awinPartners[host];
        if (!partner && awinPartners) {
          partner = Object.values(awinPartners).find(
            (p) => host === p.domain || host.endsWith(`.${p.domain}`),
          );
        }
        if (!partner && host.includes('drogal')) {
          partner = { advertiserId: '68224' };
        }
        const mid = partner?.advertiserId || '68224';
        const pub = awinPublisherId || '691887';
        affiliateUrl = `https://www.awin1.com/cread.php?awinmid=${mid}&awinaffid=${pub}&platform=dl&ued=${encodeURIComponent(url)}`;
      }

      const payload = {
        url,
        marketplaceKind,
        ...(affiliateUrl ? { affiliateUrl } : {}),
        ...(product.title ? { title: product.title } : {}),
        ...(product.price !== null && product.price !== undefined ? { price: product.price } : {}),
        ...(product.originalPrice ? { originalPrice: product.originalPrice } : {}),
        ...(product.discountPct ? { discountPct: product.discountPct } : {}),
        ...(product.images && product.images.length > 0 ? { images: product.images } : {}),
        ...(product.shipping && product.shipping !== 'UNKNOWN'
          ? { shipping: product.shipping }
          : {}),
        ...(product.couponCode ? { couponCode: product.couponCode } : {}),
      };

      const post = (extra) =>
        fetch(`${apiUrl}/api/v1/extension/capture`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${apiToken}`,
          },
          body: JSON.stringify({ ...payload, ...extra }),
        });

      try {
        const target = currentTarget;
        let res = await post(captureTargetPayload(target));
        let fellBack = false;
        if (!res.ok && target.kind !== 'triage') {
          const err = await res
            .clone()
            .json()
            .catch(() => null);
          const code = err && err.error && err.error.code;
          if (code === 'BATCH_DUPLICATE') {
            btn.innerHTML = '<span>ℹ️</span> Já está no lote';
            setTimeout(() => {
              setIdleLabel();
              btn.classList.remove('loading');
            }, 2500);
            return;
          }
          // Lote concluído/cancelado/removido (ou automação apagada): manda para a Triagem e
          // esquece o destino salvo, para o próximo clique não repetir o erro.
          if (res.status === 404 || code === 'BATCH_INACTIVE') {
            res = await post({});
            fellBack = true;
            chrome.storage.local
              .set({ lastCaptureTarget: { value: '', label: '' } })
              .catch(() => {});
          }
        }

        if (res.ok) {
          btn.innerHTML = fellBack
            ? '<span>✓</span> Destino indisponível: enviado à Triagem'
            : '<span>✓</span> Capturado!';
          btn.classList.add('success');
          // Envia o cupom explicitamente para a Central de Cupons se detectado
          if (product.couponCode) {
            fetch(`${apiUrl}/api/v1/extension/coupons`, {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json',
                Authorization: `Bearer ${apiToken}`,
              },
              body: JSON.stringify({
                code: product.couponCode,
                store: marketplaceKind,
                source: 'EXTENSION',
              }),
            }).catch(() => {});
          }
          setTimeout(() => {
            setIdleLabel();
            btn.classList.remove('loading', 'success');
          }, 3000);
        } else {
          btn.innerHTML = '<span>❌</span> Erro';
          setTimeout(() => {
            setIdleLabel();
            btn.classList.remove('loading');
          }, 2500);
        }
      } catch {
        btn.innerHTML = '<span>❌</span> Offline';
        setTimeout(() => {
          setIdleLabel();
          btn.classList.remove('loading');
        }, 2500);
      }
    });

    getOrCreateFabWrapper().appendChild(btn);
  }

  // --- Painel Flutuante de Cupons no Carrinho / Checkout ---

  function detectCartStore() {
    const currentUrl = window.location.href;
    const stores = window.AFILADOS_COUPON_STORES || {};
    for (const key of Object.keys(stores)) {
      const s = stores[key];
      if (s.cartMatch && s.cartMatch.test(currentUrl)) {
        return { key, ...s };
      }
    }
    return null;
  }

  function renderCartCouponPanel(coupons, store, apiUrl, apiToken) {
    if (document.getElementById('afilados-cart-coupons-panel')) return;

    const panel = document.createElement('div');
    panel.id = 'afilados-cart-coupons-panel';

    const header = document.createElement('div');
    header.id = 'afilados-cart-coupons-header';
    header.innerHTML = `
      <h4>
        <span>🎟️ Cupons Afilados</span>
        <span class="afilados-cart-badge-count">${coupons.length}</span>
      </h4>
      <button class="afilados-cart-toggle-btn" title="Minimizar / Expandir">—</button>
    `;

    const body = document.createElement('div');
    body.id = 'afilados-cart-coupons-body';

    coupons.forEach((coupon) => {
      const card = document.createElement('div');
      card.className = 'afilados-cart-coupon-card';
      card.dataset.couponId = coupon.id;

      let statusClass = 'afilados-status--unverified';
      let statusLabel = 'Não verificado';
      if (coupon.status === 'VALID') {
        statusClass = 'afilados-status--valid';
        statusLabel = 'Válido';
      } else if (coupon.status === 'INVALID') {
        statusClass = 'afilados-status--invalid';
        statusLabel = 'Inválido';
      }

      let discountText = coupon.description || '';
      if (coupon.discountValue) {
        const valStr =
          coupon.discountType === 'PERCENT'
            ? `${coupon.discountValue}% OFF`
            : `R$ ${coupon.discountValue} OFF`;
        discountText = discountText ? `${valStr} - ${discountText}` : valStr;
      }

      const metaParts = [];
      if (coupon.minSpend) metaParts.push(`Mín: R$ ${coupon.minSpend}`);
      if (coupon.validUntil) {
        try {
          metaParts.push(`Até ${new Date(coupon.validUntil).toLocaleDateString('pt-BR')}`);
        } catch {}
      }

      card.innerHTML = `
        <div class="afilados-cart-coupon-top">
          <span class="afilados-cart-code-tag">${coupon.code}</span>
          <span class="afilados-cart-status-badge ${statusClass}">${statusLabel}</span>
        </div>
        ${discountText ? `<div class="afilados-cart-coupon-desc">${discountText}</div>` : ''}
        ${metaParts.length > 0 ? `<div class="afilados-cart-coupon-meta">${metaParts.join(' • ')}</div>` : ''}
        <div class="afilados-cart-actions">
          <button class="afilados-btn-copy" type="button">
            <span>📋</span> Copiar e destacar campo
          </button>
          <div class="afilados-feedback-box" style="display: none;">
            <span>Funcionou?</span>
            <div class="afilados-feedback-actions">
              <button class="afilados-btn-feedback success" type="button">👍 Sim</button>
              <button class="afilados-btn-feedback fail" type="button">👎 Não</button>
            </div>
          </div>
        </div>
      `;

      const btnCopy = card.querySelector('.afilados-btn-copy');
      const feedbackBox = card.querySelector('.afilados-feedback-box');
      const btnSuccess = card.querySelector('.afilados-btn-feedback.success');
      const btnFail = card.querySelector('.afilados-btn-feedback.fail');

      btnCopy.addEventListener('click', async () => {
        try {
          await navigator.clipboard.writeText(coupon.code);
          btnCopy.innerHTML = '<span>✓</span> Código copiado!';
          btnCopy.classList.add('copied');
        } catch {
          btnCopy.innerHTML = '<span>✓</span> ' + coupon.code;
        }

        // Destaca o input de cupom no carrinho
        if (store && store.input) {
          try {
            const inputEl = document.querySelector(store.input);
            if (inputEl) {
              inputEl.scrollIntoView({ behavior: 'smooth', block: 'center' });
              inputEl.classList.add('afilados-input-highlight');
              inputEl.focus();
              setTimeout(() => {
                inputEl.classList.remove('afilados-input-highlight');
              }, 6000);
            }
          } catch {}
        }

        // Exibe opções de feedback de validação
        feedbackBox.style.display = 'flex';
      });

      const sendVerification = async (result) => {
        btnSuccess.disabled = true;
        btnFail.disabled = true;
        try {
          await fetch(`${apiUrl}/api/v1/extension/coupons/${coupon.id}/verification`, {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              Authorization: `Bearer ${apiToken}`,
            },
            body: JSON.stringify({
              result,
              metadata: {
                source: 'EXTENSION',
                appliedUrl: window.location.href,
              },
            }),
          });
          feedbackBox.innerHTML = `<span class="afilados-feedback-done">✓ Feedback registrado!</span>`;
        } catch {
          feedbackBox.innerHTML = `<span class="afilados-feedback-done">✓ Registrado localmente</span>`;
        }
      };

      btnSuccess.addEventListener('click', () => sendVerification('SUCCESS'));
      btnFail.addEventListener('click', () => sendVerification('FAILURE'));

      body.appendChild(card);
    });

    // Toggle minimizar
    const toggleBtn = header.querySelector('.afilados-cart-toggle-btn');
    const toggleCollapse = () => {
      panel.classList.toggle('collapsed');
      const isCollapsed = panel.classList.contains('collapsed');
      toggleBtn.textContent = isCollapsed ? '+' : '—';
      body.style.display = isCollapsed ? 'none' : 'flex';
    };
    header.addEventListener('click', toggleCollapse);

    panel.appendChild(header);
    panel.appendChild(body);
    document.body.appendChild(panel);
  }

  async function initCartCouponPanel() {
    const store = detectCartStore();
    if (!store) return;
    if (document.getElementById('afilados-cart-coupons-panel')) return;

    if (typeof chrome === 'undefined' || !chrome.storage) return;

    try {
      const saved = await chrome.storage.local.get(['apiUrl', 'apiToken']);
      const apiUrl = (saved.apiUrl || 'http://localhost:3011').replace(/\/+$/, '');
      const apiToken = saved.apiToken;
      if (!apiToken) return;

      const host = window.location.hostname.replace(/^www\./, '').toLowerCase();
      let queryUrl = `${apiUrl}/api/v1/extension/coupons?store=${store.key}`;
      if (store.key === 'AWIN') {
        queryUrl += `&domain=${encodeURIComponent(host)}`;
      }
      const res = await fetch(queryUrl, {
        headers: { Authorization: `Bearer ${apiToken}` },
      });
      if (!res.ok) return;
      const data = await res.json();
      const list = Array.isArray(data) ? data : data?.coupons || [];
      if (list.length > 0) {
        renderCartCouponPanel(list, store, apiUrl, apiToken);
      }
    } catch {}
  }

  // Container flutuante que agrupa os botões (Enviar Produto / Copiar links) com um botão
  // de ocultar — colapsa para uma bolinha pequena no canto, útil pra não atrapalhar a
  // navegação em páginas onde o usuário não quer capturar nada no momento. Estado persistido
  // em localStorage para manter a preferência entre páginas do mesmo site.
  function getOrCreateFabWrapper() {
    let wrapper = document.getElementById('afilados-fab-wrapper');
    if (wrapper) return wrapper.querySelector('#afilados-fab-buttons');

    wrapper = document.createElement('div');
    wrapper.id = 'afilados-fab-wrapper';

    const toggle = document.createElement('button');
    toggle.id = 'afilados-fab-toggle';
    toggle.title = 'Ocultar / Mostrar';
    toggle.innerHTML = '<span>✕</span>';

    const buttons = document.createElement('div');
    buttons.id = 'afilados-fab-buttons';

    let collapsed = false;
    try {
      collapsed = localStorage.getItem('afilados_fab_collapsed') === 'true';
    } catch {}

    function applyState() {
      wrapper.classList.toggle('afilados-fab-collapsed', collapsed);
      toggle.innerHTML = collapsed ? '<span>⚡</span>' : '<span>✕</span>';
      toggle.title = collapsed ? 'Mostrar botões do Afilados' : 'Ocultar botões do Afilados';
    }

    toggle.addEventListener('click', () => {
      collapsed = !collapsed;
      try {
        localStorage.setItem('afilados_fab_collapsed', String(collapsed));
      } catch {}
      applyState();
    });

    applyState();
    wrapper.appendChild(buttons);
    wrapper.appendChild(toggle);
    document.body.appendChild(wrapper);
    return buttons;
  }

  async function shouldInjectButtons() {
    const url = window.location.href;
    if (
      url.includes('mercadolivre.com.br') ||
      url.includes('amazon.com.br') ||
      url.includes('magazineluiza.com.br') ||
      url.includes('magazinevoce.com.br') ||
      url.includes('shopee.com.br') ||
      url.includes('aliexpress.com')
    ) {
      return true;
    }
    const host = window.location.hostname.replace(/^www\./, '').toLowerCase();
    if (host === 'drogal.com.br' || host.endsWith('.drogal.com.br')) return true;
    const DEFAULT_PARTNERS = [
      'centauro.com.br',
      'dafiti.com.br',
      'nike.com.br',
      'boticario.com.br',
      'sephora.com.br',
      'fastshop.com.br',
      'netshoes.com.br',
      'zattini.com.br',
    ];
    if (DEFAULT_PARTNERS.some((p) => host === p || host.endsWith(`.${p}`))) return true;
    if (typeof chrome !== 'undefined' && chrome.storage) {
      try {
        const { awinPartners } = await chrome.storage.local.get(['awinPartners']);
        if (awinPartners) {
          if (awinPartners[host]) return true;
          if (
            Object.values(awinPartners).some(
              (p) => host === p.domain || host.endsWith(`.${p.domain}`),
            )
          ) {
            return true;
          }
        }
      } catch {}
    }
    return false;
  }

  // Injeta após carregar a página
  async function injectButtons() {
    const supported = await shouldInjectButtons();
    if (!supported) return;

    injectFloatingButton();
    injectCopyLinksButton();
    void initCartCouponPanel();
  }
  if (document.readyState === 'complete' || document.readyState === 'interactive') {
    injectButtons();
  } else {
    window.addEventListener('DOMContentLoaded', injectButtons);
  }
})();
